﻿using Dominio;


namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Sistema s = new Sistema();
           
            int op = -1;
            
            // El usuario digita que opcion quiere
            try{
                while (op != 0)
            {
                Console.Clear();
                Console.WriteLine("1 - Ver usuarios registrados");
                Console.WriteLine("2 - Obtener pagos de usario por email");
                Console.WriteLine("3 - Dar de alta un usuario");
                Console.WriteLine("4 - Encontrar miembros de equipo");
                Console.WriteLine("0 - Salir");



                try{
                    op = int.Parse(Console.ReadLine());
                }
                catch (FormatException) {
                    // mensaje por si el usuario coloca una letra en ves de un numero
                     Console.ForegroundColor = ConsoleColor.Red;
                     Console.WriteLine("Error, debe ingresar un numero valido.");
                     Console.ResetColor();
                    //para volver al menu sin que se rompa el programa
                     op = -1;
                }
                

                // segun el numero digitado por el usuario es el if en el que va a entrar


                // en esta seccion obtengo a todos los clientes que tengo en el momento del programa
                if (op.Equals(1))
                {
                    
                    foreach (Usuario u in s.GetClientes())
                    {
                        Console.WriteLine($"{u.Nombre} - {u.Email} - {u.Equipo}");

                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                    Console.ResetColor();
                    Console.ReadKey();
                }
                // en esta seccion obtengo los pagos del usuario ingresando su mail
                else if (op.Equals(2))
                {
                    Console.WriteLine("Escriba un email:");
                    string email = Console.ReadLine();
                    List<Pago> pagos = s.GetPagosByEmail(email);
                    
                    foreach (Pago p in pagos)
                    {
                        Console.WriteLine($"{p}"); 
                    }
                    
                     Console.ForegroundColor = ConsoleColor.Red;
                     Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                     Console.ResetColor();
                }
                
                // en esta seccion damos de alta al usuario, le pedimos que ingrese un nombre, apellido, contrasenia y el equipo
                else if (op.Equals(3))
                {
                    Console.WriteLine("Escriba su nombre:");
                    string nom = Console.ReadLine();

                    Console.WriteLine("Escriba su apellido:");
                    string ape = Console.ReadLine();
                    
                    string pas = "";

                    try {
                    Console.WriteLine("Escriba una contrasenia:");
                    Console.WriteLine("Con mas de 8 caracteres");
                    pas = Console.ReadLine();
                    if(pas.Length < 8){
                            throw new Exception("La contrasenia debe tener mas de 8 caracteres");
                            Console.ForegroundColor = ConsoleColor.Red;
                     Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                     Console.ResetColor();
                    }
                    }catch(Exception e){
                        Console.WriteLine("Hubo un error.");
                        Console.WriteLine($"{e.Message}");
                        Console.ReadKey();
                        // lo manda al menu
                        continue;
                    }
                   
                    string mail =  s.GenerarEmail(nom, ape);

                    Console.WriteLine("Elija un equipo:");
                    Console.WriteLine("1 - PowelPeralta");
                    Console.WriteLine("2 - Creature");
                    Console.WriteLine("3 - SantaCruz");
                    Console.WriteLine("4 - Element");
                    
                    try 
                    {

                    int equipo = int.Parse(Console.ReadLine());
                    Equipo eq = s.BuscarEquipo(equipo);

                    if(eq == null) {
                        Console.WriteLine("Equipo no encontrado"); 
                        Console.ReadKey();
                        // vuelve al menu principal
                        continue;
                    }
                     else
                    {

                    Usuario usuario = new Usuario(nom, ape, pas, mail, eq);
                    s.AltaUsuario(usuario);

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Usuario creado con exito.");
                    Console.ResetColor();

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                    Console.ResetColor();
                    }                    
                }catch (FormatException){
                        Console.WriteLine("Debe ingresar un numer valido (1 al 4)");
                        Console.ReadKey();
                        Console.ForegroundColor = ConsoleColor.Red;
                     Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                     Console.ResetColor();
                        // Vuelve al menu
                        continue;
                }catch(Exception e){
                        Console.WriteLine($"Error inesperado: {e.Message}");
                    Console.ReadKey();
                    Console.ForegroundColor = ConsoleColor.Red;
                     Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                     Console.ResetColor();
                        // Vuelve al menu
                        continue;
                }
                   
                    
                }
                
                // esta seccion busca a todos los usuarios que tengan el equipo que ingreso el usuario en el programa
                else if (op.Equals(4))
                {
                    Console.WriteLine("Escriba el nombre del equipo:");
                    string nom = Console.ReadLine();
                    if (s.ValidarNombreEquipo(nom))
                    {
                        List<Usuario> listaIntegrantes = s.GetUsuariosByEquipo(nom);

                        foreach (Usuario u in listaIntegrantes)
                        {
                            Console.WriteLine($"{u}");
                        }
                       
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.WriteLine("nombre de equipo no valido");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                        Console.ResetColor();
                    }
                }
                Console.ReadKey();

            }
            // por si hay algun error que no lo tuvimos contemplado, creamos un try-catch para todo el programa
            }catch(Exception c){
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"ERROR INESPERADO.");
                Console.ResetColor();
                Console.WriteLine($"---------------------------------------------------------------------");
                Console.WriteLine($"{c.Message}");
            }
            

        }
    }
}
