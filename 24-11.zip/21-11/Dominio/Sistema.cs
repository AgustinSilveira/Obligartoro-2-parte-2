﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Dominio
{
    public class Sistema
    {
        private List<Usuario> _usuarios = new List<Usuario>();
        private List<Equipo> _equipos = new List<Equipo>();
        private List<Pago> _pagos = new List<Pago>();
        private List<TipoDeGastos> _tiposDeGastos = new List<TipoDeGastos>();
        private static Sistema _instancia = null;

        public Sistema()
        {
            PrecargarDatos();
        }


        public void PrecargarDatos()
        {

            Equipo equipo1 = new Equipo("PowelPeralta");
            Equipo equipo2 = new Equipo("Creature");
            Equipo equipo3 = new Equipo("SantaCruz");
            Equipo equipo4 = new Equipo("Element");

            AltaEquipo(equipo1);
            AltaEquipo(equipo2);
            AltaEquipo(equipo3);
            AltaEquipo(equipo4);

            Usuario usuario1 = new Usuario("Agustin", "Silveira", "agus1234", "agusil@laEmpresa.com", equipo1, new DateTime(2020, 4, 15), "Gerente");
            Usuario usuario2 = new Usuario("Valentin", "Gonzalez", "vale1234", "valgon@laEmpresa.com", equipo2, new DateTime(2020, 3, 22), "Gerente");
            Usuario usuario3 = new Usuario("Sofia", "Martinez", "sofi1234", "sofmar@laEmpresa.com", equipo3, new DateTime(2020, 6, 10), "Gerente");
            Usuario usuario4 = new Usuario("Camila", "Fernandez", "cami1234", "camfer@laEmpresa.com", equipo4, new DateTime(2020, 8, 5), "Gerente");
            Usuario usuario5 = new Usuario("Joaquin", "Lopez", "joaq1234", "joalop@laEmpresa.com", equipo1, new DateTime(2020, 2, 14), "Empleado");
            Usuario usuario6 = new Usuario("Mateo", "Pereira", "mate1234", "matper@laEmpresa.com", equipo2, new DateTime(2020, 7, 1), "Empleado");
            Usuario usuario7 = new Usuario("Lucia", "Rodriguez", "luci1234", "lucrod@laEmpresa.com", equipo3, new DateTime(2020, 9, 18), "Empleado");
            Usuario usuario8 = new Usuario("Martina", "Torres", "mart1234", "martor@laEmpresa.com", equipo4, new DateTime(2020, 11, 20), "Empleado");
            Usuario usuario9 = new Usuario("Federico", "Alvarez", "fede1234", "fedalv@laEmpresa.com", equipo1, new DateTime(2020, 10, 5), "Empleado");
            Usuario usuario10 = new Usuario("Paula", "Suarez", "paul1234", "pausua@laEmpresa.com", equipo2, new DateTime(2020, 1, 13), "Empleado");
            Usuario usuario11 = new Usuario("Nicolas", "Ramos", "nico1234", "nicram@laEmpresa.com", equipo3, new DateTime(2020, 3, 17), "Empleado");
            Usuario usuario12 = new Usuario("Florencia", "Gomez", "flor1234", "flogom@laEmpresa.com", equipo4, new DateTime(2020, 5, 23), "Empleado");
            Usuario usuario13 = new Usuario("Sebastian", "Dominguez", "seba1234", "sebdom@laEmpresa.com", equipo1, new DateTime(2020, 8, 30), "Empleado");
            Usuario usuario14 = new Usuario("Carolina", "Mendez", "caro1234", "carmen@laEmpresa.com", equipo2, new DateTime(2020, 9, 4), "Empleado");
            Usuario usuario15 = new Usuario("Diego", "Fernandez", "dieg1234", "diefer@laEmpresa.com", equipo3, new DateTime(2020, 7, 15), "Empleado");
            Usuario usuario16 = new Usuario("Micaela", "Castro", "mica1234", "miccas@laEmpresa.com", equipo4, new DateTime(2020, 1, 1), "Empleado");
            Usuario usuario17 = new Usuario("Gonzalo", "Silva", "gonz1234", "gonsil@laEmpresa.com", equipo1, new DateTime(2020, 6, 20), "Empleado");
            Usuario usuario18 = new Usuario("Bruno", "Cabrera", "brun1234", "brucab@laEmpresa.com", equipo2, new DateTime(2020, 12, 3), "Empleado");
            Usuario usuario19 = new Usuario("Andrea", "Vazquez", "andr1234", "andvaz@laEmpresa.com", equipo3, new DateTime(2020, 4, 10), "Empleado");
            Usuario usuario20 = new Usuario("Rodrigo", "Fernandez", "rodr1234", "rodfer@laEmpresa.com", equipo4, new DateTime(2020, 8, 14), "Empleado");
            Usuario usuario21 = new Usuario("Pablo", "Herrera", "pabl1234", "pabherr@laEmpresa.com", equipo1, new DateTime(2020, 11, 30), "Empleado");
            Usuario usuario22 = new Usuario("Milagros", "Diaz", "mila1234", "mildia@laEmpresa.com", equipo2, new DateTime(2020, 9, 25), "Empleado");





            AltaUsuario(usuario1);
            AltaUsuario(usuario2);
            AltaUsuario(usuario3);
            AltaUsuario(usuario4);
            AltaUsuario(usuario5);
            AltaUsuario(usuario6);
            AltaUsuario(usuario7);
            AltaUsuario(usuario8);
            AltaUsuario(usuario9);
            AltaUsuario(usuario10);
            AltaUsuario(usuario11);
            AltaUsuario(usuario12);
            AltaUsuario(usuario13);
            AltaUsuario(usuario14);
            AltaUsuario(usuario15);
            AltaUsuario(usuario16);
            AltaUsuario(usuario17);
            AltaUsuario(usuario18);
            AltaUsuario(usuario19);
            AltaUsuario(usuario20);
            AltaUsuario(usuario21);

            TipoDeGastos tg1 = new TipoDeGastos("Auto", "Abolladura");
            TipoDeGastos tg2 = new TipoDeGastos("Comida", "Almuerzo de equipo");
            TipoDeGastos tg3 = new TipoDeGastos("Viaje", "Pasaje de avión");
            TipoDeGastos tg4 = new TipoDeGastos("Hospedaje", "Hotel por capacitación");
            TipoDeGastos tg5 = new TipoDeGastos("Tecnología", "Compra de mouse");
            TipoDeGastos tg6 = new TipoDeGastos("Papelería", "Resmas de hojas");
            TipoDeGastos tg7 = new TipoDeGastos("Transporte", "Taxi al cliente");
            TipoDeGastos tg8 = new TipoDeGastos("Mantenimiento", "Reparación de aire acondicionado");
            TipoDeGastos tg9 = new TipoDeGastos("Marketing", "Impresión de folletos");
            TipoDeGastos tg10 = new TipoDeGastos("Capacitación", "Curso online de programación");

            AltaTipoGastos(tg1);
            AltaTipoGastos(tg2);
            AltaTipoGastos(tg3);
            AltaTipoGastos(tg4);
            AltaTipoGastos(tg5);
            AltaTipoGastos(tg6);
            AltaTipoGastos(tg7);
            AltaTipoGastos(tg8);
            AltaTipoGastos(tg9);
            AltaTipoGastos(tg10);




            Recurrente rec1 = new Recurrente(usuario1, "Almuerzos semanales del equipo", tg2, 500, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec2 = new Recurrente(usuario2, "Servicio mensual de transporte para oficina", tg7, 1500, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 3);
            Recurrente rec3 = new Recurrente(usuario3, "Catering mensual para reuniones", tg2, 300, new DateTime(2025, 2, 1), new DateTime(2025, 7, 1), 6, 1);
            Recurrente rec4 = new Recurrente(usuario4, "Publicidad mensual en redes sociales", tg9, 1200, new DateTime(2025, 1, 15), new DateTime(2025, 12, 15), 12, 5);
            Recurrente rec5 = new Recurrente(usuario5, "Mantenimiento del aire acondicionado", tg8, 2000, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec6 = new Recurrente(usuario6, "Servicio técnico de impresoras", tg8, 2500, new DateTime(2025, 2, 1), new DateTime(2025, 12, 1), 11, 4);
            Recurrente rec7 = new Recurrente(usuario7, "Taxi mensual para visitas a clientes", tg7, 800, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 6);
            Recurrente rec8 = new Recurrente(usuario8, "Gastos de viaje para reuniones externas", tg3, 400, new DateTime(2025, 1, 5), new DateTime(2025, 12, 5), 12, 3);
            Recurrente rec9 = new Recurrente(usuario9, "Almuerzos de equipo", tg2, 450, new DateTime(2025, 3, 1), new DateTime(2025, 8, 1), 6, 2);
            Recurrente rec10 = new Recurrente(usuario10, "Reparaciones mensuales de equipos informáticos", tg8, 1800, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 4);
            Recurrente rec11 = new Recurrente(usuario11, "Reposición mensual de materiales tecnológicos", tg5, 900, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 7);
            Recurrente rec12 = new Recurrente(usuario12, "Campañas de marketing digital", tg9, 1300, new DateTime(2025, 2, 1), new DateTime(2025, 11, 1), 10, 3);
            Recurrente rec13 = new Recurrente(usuario13, "Transporte interno del personal", tg7, 700, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 5);
            Recurrente rec14 = new Recurrente(usuario14, "Cursos mensuales de formación de personal", tg10, 2500, new DateTime(2025, 3, 1), new DateTime(2025, 8, 1), 6, 1);
            Recurrente rec15 = new Recurrente(usuario15, "Mantenimiento de software de diseño", tg8, 600, new DateTime(2025, 1, 15), new DateTime(2025, 12, 15), 12, 6);
            Recurrente rec16 = new Recurrente(usuario16, "Servicio mensual de transporte corporativo", tg7, 900, new DateTime(2025, 2, 1), new DateTime(2025, 12, 1), 11, 4);
            Recurrente rec17 = new Recurrente(usuario17, "Cenas de equipo", tg2, 500, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec18 = new Recurrente(usuario18, "Comidas de trabajo con clientes", tg2, 300, new DateTime(2025, 2, 1), new DateTime(2025, 7, 1), 6, 1);
            Recurrente rec19 = new Recurrente(usuario19, "Reparación mensual de equipos de oficina", tg8, 2200, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 5);
            Recurrente rec20 = new Recurrente(usuario20, "Taxi mensual para reuniones con clientes", tg7, 1500, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 3);
            Recurrente rec21 = new Recurrente(usuario21, "Viajes corporativos a clientes", tg3, 400, new DateTime(2025, 1, 5), new DateTime(2025, 12, 5), 12, 3);

            AltaPago(rec1);
            AltaPago(rec2);
            AltaPago(rec3);
            AltaPago(rec4);
            AltaPago(rec5);
            AltaPago(rec6);
            AltaPago(rec7);
            AltaPago(rec8);
            AltaPago(rec9);
            AltaPago(rec10);
            AltaPago(rec11);
            AltaPago(rec12);
            AltaPago(rec13);
            AltaPago(rec14);
            AltaPago(rec15);
            AltaPago(rec16);
            AltaPago(rec17);
            AltaPago(rec18);
            AltaPago(rec19);
            AltaPago(rec20);
            AltaPago(rec21);

            Unico uni1 = new Unico(usuario1, "Pasaje aéreo a reunión con cliente", tg3, 1200, 2001, new DateTime(2025, 1, 5));
            Unico uni2 = new Unico(usuario2, "Reparación de abolladura en vehículo", tg3, 2800, 2002, new DateTime(2025, 1, 7));
            Unico uni3 = new Unico(usuario3, "Gastos de viaje corto al cliente", tg3, 450, 2003, new DateTime(2025, 1, 10));
            Unico uni4 = new Unico(usuario4, "Inscripción a curso de capacitación", tg10, 3200, 2004, new DateTime(2025, 1, 12));
            Unico uni5 = new Unico(usuario5, "Compra de mouse inalámbrico", tg5, 700, 2005, new DateTime(2025, 1, 15));
            Unico uni6 = new Unico(usuario6, "Pago hotel por viaje de trabajo", tg4, 2500, 2006, new DateTime(2025, 1, 18));
            Unico uni7 = new Unico(usuario7, "Compra de teclado nuevo", tg5, 500, 2007, new DateTime(2025, 1, 20));
            Unico uni8 = new Unico(usuario8, "Vuelo de ida a conferencia", tg3, 1900, 2008, new DateTime(2025, 1, 22));
            Unico uni9 = new Unico(usuario9, "Reserva de hotel por capacitación", tg4, 1200, 2009, new DateTime(2025, 1, 25));
            Unico uni10 = new Unico(usuario10, "Compra de cables HDMI", tg5, 800, 2010, new DateTime(2025, 1, 28));
            Unico uni11 = new Unico(usuario11, "Viaje en ómnibus a sede central", tg3, 1500, 2011, new DateTime(2025, 2, 1));
            Unico uni12 = new Unico(usuario12, "Compra de resmas y útiles de oficina", tg6, 2200, 2012, new DateTime(2025, 2, 3));
            Unico uni13 = new Unico(usuario13, "Servicio de taxi al cliente", tg7, 900, 2013, new DateTime(2025, 2, 5));
            Unico uni14 = new Unico(usuario14, "Inscripción a webinar de formación", tg10, 2700, 2014, new DateTime(2025, 2, 7));
            Unico uni15 = new Unico(usuario15, "Pasaje de tren por viaje laboral", tg3, 1300, 2015, new DateTime(2025, 2, 10));
            Unico uni16 = new Unico(usuario16, "Reparación de aire acondicionado", tg8, 3500, 2016, new DateTime(2025, 2, 12));
            Unico uni17 = new Unico(usuario17, "Viaje corto en taxi a reunión", tg3, 600, 2017, new DateTime(2025, 2, 15));
            Unico uni18 = new Unico(usuario18, "Curso presencial de actualización", tg10, 2500, 2018, new DateTime(2025, 2, 18));
            Unico uni19 = new Unico(usuario19, "Compra de pendrives para oficina", tg5, 1200, 2019, new DateTime(2025, 2, 20));
            Unico uni20 = new Unico(usuario20, "Pasaje de colectivo interdepartamental", tg3, 800, 2020, new DateTime(2025, 2, 22));
            Unico uni21 = new Unico(usuario21, "Taxi al aeropuerto", tg7, 950, 2021, new DateTime(2025, 2, 25));


            AltaPago(uni1);
            AltaPago(uni2);
            AltaPago(uni3);
            AltaPago(uni4);
            AltaPago(uni5);
            AltaPago(uni6);
            AltaPago(uni7);
            AltaPago(uni8);
            AltaPago(uni9);
            AltaPago(uni10);
            AltaPago(uni11);
            AltaPago(uni12);
            AltaPago(uni13);
            AltaPago(uni14);
            AltaPago(uni15);
            AltaPago(uni16);
            AltaPago(uni17);
            AltaPago(uni18);
            AltaPago(uni19);
            AltaPago(uni20);
            AltaPago(uni21);

        }


        public List<Usuario> GetClientes()
        {
            return _usuarios;
        }
        public List<Equipo> GetEquipos()
        {
            return _equipos;
        }


        public List<Pago> GetPagos()
        {
            return _pagos;
        }

        public List<TipoDeGastos> GetTG()
        {
            return _tiposDeGastos;
        }
        

        public void AltaUsuario(Usuario u)
        {
            u.Validar();
            if (ExisteMail(u))
            {
                throw new Exception("Este mail ya exsiste");

            }
            _usuarios.Add(u);
        }

        public string GenerarEmail(string n, string a)
        {
            string email = n.Substring(0, 3) + a.Substring(0, 3) + "@laEmpresa.com"; //obtengo las primeras 3 letras de cada string y las juntamos
            return email;
        }
        public bool ExisteMail(Usuario x) //para cuando el email esta repetido
        {

            foreach (Usuario u in _usuarios)
            {
                if (u.Email == x.Email)
                {
                    return true;
                }
            }
            return false;
        }

        public void AltaTipoGastos(TipoDeGastos t)
        {
            t.Validar();
            _tiposDeGastos.Add(t);
        }

        public void AltaEquipo(Equipo e)
        {
            e.Validar();
            _equipos.Add(e);
        }

        public Equipo BuscarEquipo(int id)
        {
            foreach (Equipo e in _equipos)
            {
                if (e.Id == id)
                {
                    return e;
                }
            }
            return null;
        }


        public void AltaPago(Pago p)
        {
            if (string.IsNullOrEmpty(p.Descripcion) || p.Monto <= 0 || p.TipoDeGasto == null )
            {
                
                throw new Exception("Datos inválidos");
            }

            _pagos.Add(p);
        }

        public List<Pago> GetPagosByEmail(string email)
        {
            List<Pago> pagosDelUsuario = new List<Pago>();

            foreach (Pago p in _pagos)
            {
                if (p.Usuario != null && p.Usuario.Email == email)
                {
                    pagosDelUsuario.Add(p);
                }
            }

            return pagosDelUsuario;
        }
        public List<Usuario> GetUsuariosByEquipo(string equipo)
        {
            List<Usuario> ret = new List<Usuario>();

            foreach (Usuario u in _usuarios)
            {
                if (u.Equipo.Nombre == equipo)
                {
                    ret.Add(u);
                }
            }
            ret.Sort();
            return ret;
        }

        public bool ValidarNombreEquipo(string equipo)//si tiene nombre de equipo o no
        {
            foreach (Equipo e in _equipos)
            {
                if (equipo == e.Nombre)
                {
                    return true;
                }
            }
            return false;
        }

        public Usuario VerificarExixtencia(string email, string contrasenia)//para el login, y buscar el usuario
        {
            foreach (Usuario c in _usuarios)
            {
                if (c.Email.Equals(email) && c.Contrasenia.Equals(contrasenia))
                {

                    return c;
                }
            }
            return null;
        }

        public static Sistema GetInstancia()// SINGLETON
        {
            if (_instancia == null)
            {
                _instancia = new Sistema();
            }
            return _instancia;
        }



        public List<Pago> GetTodosLosPagos(int? idUsuario)//devuelve los pagos del logueado
        {
            List<Pago> pagosDelMes = new List<Pago>(); 


            foreach (Pago p in _pagos)
            {
                if (p.Usuario.Id == idUsuario )
                {
                    pagosDelMes.Add(p);
                }
            }
            return pagosDelMes;
        }


        public Usuario GetUsuarioById(int? id)
        {
            foreach (Usuario u in _usuarios)
            {
                if (u.Id == id)
                {
                    return u;
                }
            }
            return null;
        }

        public List<Pago> GetPagosPorEquipo(int? id, DateTime hoy )// devuelve los pagos de todo el equipo
        {
            Usuario usuario = GetUsuarioById(id);
            List<Pago> pagosDelMes = BuscarPagosByFecha(hoy);
            List<Pago> pagosDelEquipo = new List<Pago>();

            foreach (Pago p in pagosDelMes)
            {
                if(p.Usuario.Equipo.Nombre == usuario.Equipo.Nombre)
                {
                    pagosDelEquipo.Add(p);
                }
            }return pagosDelEquipo;
        }
        
        public List<Pago> GetPagosByLista(Usuario usu, List<Pago> listaPagos)// recibindo una lista de pagos con una fecha indicada filtra los que son de tu equipo
        {
            List<Pago> pagosDelEquipo = new List<Pago>();

            foreach (Pago p in listaPagos)
            {

                if (p.Usuario.Equipo.Nombre == usu.Equipo.Nombre)
                {
                    pagosDelEquipo.Add(p);
                }
            }
            return pagosDelEquipo;
        }

        public List<Pago> BuscarPagosByFecha(DateTime fecha)// devuelve la lista de pagos con una fecha indicada
        {
            List<Pago> pagos = new List<Pago>();
            foreach (Pago p in _pagos)

            {
                if (p.FechaIngresoPago.Month == fecha.Month && p.FechaIngresoPago.Year == fecha.Year)
                {
                    pagos.Add(p);
                }
            }
            return pagos;
        }

        public double CalcularGastosDelMesById(int? id)// monto 
        {
            Usuario usuario = GetUsuarioById(id);
            double monto = 0;
            foreach (Pago p in _pagos)
            {
                if (p.Usuario.Id == usuario.Id)
                    monto += p.Monto;
            }
            return monto;
        }

        public TipoDeGastos GetTgById(int? id)// encuantra el tipo de gasto buscado por su id
        {
            foreach(TipoDeGastos tg in _tiposDeGastos)
            {
                if(tg.Id == id)
                {
                    return tg;
                }
            }return null;
        }

        public void EliminarTg(int  id) // elimina un tipo de gasto
        {
            
            
                for (int i = 0; i < _tiposDeGastos.Count; i++)
                {
                    if (_tiposDeGastos[i].Id.Equals(id))
                    {
                        _tiposDeGastos.RemoveAt(i);// no puede eliminar un tg si ya esta usado
                    }
                }
        
            
        }
        public bool TgEnUso(int id)// se fija si el tipo de gasto seleccionado para eliminar ya esta en uso
        {
            foreach (Pago p in _pagos)
            {
                if (p.TipoDeGasto.Id == id)
                {
                    return true;
                }
            }
            return false;
        }
        
        

        

        public DateTime SumarMeses(DateTime fecha, int meses)//suma los meses segun las cuotas indicadas en el html
        {
          
            return fecha.AddMonths(meses);
        }

        


    }
}
