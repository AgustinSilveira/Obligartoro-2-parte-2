﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;

namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class TipoDeGastoController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult CargarNuevoTG()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CargarNuevoTG(TipoDeGastos tgNuevo)
        {

            try
            {
                s.AltaTipoGastos(tgNuevo);  
                ViewBag.Mensaje = "Tipo de gasto guardado correctamente.";
            }
            catch (Exception e)
            {
               
                ViewBag.Error = "Los campos tienen que estar completos";
            }
            return View();
        }
        public IActionResult EliminarTG(int id)
        {
            
            TipoDeGastos tg = s.GetTgById(id);
            return View(tg);
        }
        [HttpPost]
        public IActionResult EliminarTG(int id, IFormCollection i)
        {
            if (s.TgEnUso(id)== false)
            {
                s.EliminarTg(id);
                return RedirectToAction("ListarTG");
            }
            else
            {
                                                                                                                                                         
                ViewBag.msj = "No se puede eliminar este tipo de gasto porque ya esta en uso";
                TipoDeGastos tg = s.GetTgById(id);
                return View(tg);
            }
            
               
        }



        public IActionResult ListarTG()
        {
            List<TipoDeGastos> tg = s.GetTG();
            return View(tg);
        }
    }
}
