﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;

namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class CargarPago : Controller
    {
        public IActionResult CargarPagos()
        {
            return View();
        }
    }

}
