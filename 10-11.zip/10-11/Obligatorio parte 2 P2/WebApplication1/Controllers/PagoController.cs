﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;
namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult ListarPagosDelMes()
        {
           
            List<Pago> pagos = s.GetPagosDelMes(HttpContext.Session.GetInt32("LogueadoId"));
            return View(pagos);

        }
    }
}
