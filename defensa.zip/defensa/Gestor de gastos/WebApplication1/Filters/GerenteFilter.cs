﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace WebApplication1.Filters
{
    public class GerenteFilter : ActionFilterAttribute
    {
        Sistema s = Sistema.GetInstancia();
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var session = context.HttpContext.Session;
            var logueadoId = session.GetInt32("LogueadoId");
            var logueadoRol = s.GetLogueadoRol(logueadoId);

            if (logueadoRol)
            {
                // Es empleado - redirigir al home
                context.Result = new RedirectToActionResult("Index", "Home", null);
            }

            base.OnActionExecuting(context);
        }
    }
}
