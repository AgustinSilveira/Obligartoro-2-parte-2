﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Recurrente : Pago 
    {
        public DateTime? FechaHasta { get; set; }
        public int Cuotas { get; set; }
        public int CuotasPagas { get; set; }
       



        //string recurrente
        public Recurrente (Usuario usu, string descripcion,TipoDeGastos tg, double monto, DateTime fechaIngresoPago, DateTime fin, int cuotas, int cuotasPagas):base(usu, descripcion, monto, tg, fechaIngresoPago)
        {

            FechaHasta = fin ;
            Cuotas = cuotas;
            CuotasPagas = cuotasPagas;

        }
        
        public Recurrente() : base()
        {

        }

        



    }
}
