﻿using Dominio;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class LoginController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel lm)
        {
            Usuario buscado = s.VerificarExixtencia(lm.Email, lm.Password);
            if (buscado != null)
            {
                //aca tiene que estar el usuario con sus datos logeado
                HttpContext.Session.SetInt32("LogueadoId", buscado.Id);
                HttpContext.Session.SetString("LogueadoNombre", buscado.Nombre + " " + buscado.Apellido);
                HttpContext.Session.SetString("LogueadoRol", buscado.Rol);

                return RedirectToAction("Index", "Home");
            }else{
                ViewBag.msg = "Error en los datos";
                return View();
            }
            
        }
        public IActionResult Logout()
        {

            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Login");

        }

    }
}
