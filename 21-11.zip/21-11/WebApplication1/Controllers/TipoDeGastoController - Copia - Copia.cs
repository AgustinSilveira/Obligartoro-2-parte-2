﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Filters;

namespace WebApplication1.Controllers
{
    [LoginFilter]
    public class CargarPagos : Controller
    {
        public IActionResult TipoDePagos()
        {
            return View();
        }
    }
}
