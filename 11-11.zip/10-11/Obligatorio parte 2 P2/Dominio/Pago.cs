﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace Dominio
{
    public abstract class Pago
    {
        private static int _ultimoId = 0;
        public int Id { get; set; }
        public Usuario Usuario { get; set; }
        public string Descripcion { get; set; }
        public double Monto { get; set; }
        public TipoDeGastos TipoDeGasto { get; set; }

       // public string Tipo { get; set; }


        public override string ToString()
        {
            return $"{Descripcion}";
        }

        public Pago()
        {
            Id = _ultimoId++;
        }
        public Pago(Usuario us, string descripcion, double monto, TipoDeGastos ts)
        {
            Id = _ultimoId++;
            Usuario = us;
            Descripcion = descripcion;
            Monto = monto;
            TipoDeGasto = ts;
            //Tipo = tipo;
        }
        
        
        
        
        //public abstract double CalcularMonto(int monto)
        //{
            //
        //}

    }
}
   



    

    

